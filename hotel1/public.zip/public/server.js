const express = require('express');
const fs = require('fs');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;
const FILES_DIR = path.join(__dirname, '../files');

app.use(cors());
app.use(express.json());

if (!fs.existsSync(FILES_DIR)) fs.mkdirSync(FILES_DIR);

// Get files
app.get('/files', (req, res) => {
  const files = fs.readdirSync(FILES_DIR).map(name => {
    const content = fs.readFileSync(path.join(FILES_DIR, name), 'utf-8');
    const stats = fs.statSync(path.join(FILES_DIR, name));
    return { name, content, created: stats.birthtime };
  });
  res.json(files);
});

// Save or update
app.post('/files', (req, res) => {
  const { name, content } = req.body;
  fs.writeFileSync(path.join(FILES_DIR, name), content || '');
  res.json({ message: 'Saved' });
});

// Rename
app.put('/files/:oldName', (req, res) => {
  const oldPath = path.join(FILES_DIR, req.params.oldName);
  const newName = req.body.newName;
  fs.renameSync(oldPath, path.join(FILES_DIR, newName));
  res.json({ message: 'Renamed' });
});

// Delete
app.delete('/files/:name', (req, res) => {
  const filePath = path.join(FILES_DIR, req.params.name);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    res.json({ message: 'Deleted' });
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
